//connected!!

//get the stripe publishable key
// fetch("/config/")
// .then((result) => { return result.json(); })
// .then((data) => {
//   // Initialize Stripe.js
//   const stripe = Stripe(data.publicKey);
// });
